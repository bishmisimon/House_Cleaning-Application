package com.example.cleaningapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;



import java.util.ArrayList;
import java.util.List;
public class Customer {

    private int ID;
    private String fullname;
    private String HomeLocation;
    private String Date;
    private String Time;
    private String Description;
    private byte[] Image;

    public Customer()
    {

    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setFullname(String fullname)

    {
        this.fullname=fullname;
    }
    public void setHomeLocation(String HomeLocation)

    {
        this.HomeLocation=HomeLocation;
    }

    public void setDate(String date) {
        Date = date;
    }



    public void setTime(String time) {
        Time = time;
    }


    public void setDescription(String description) {
        Description = description;
    }


    public void setImage(byte[] image) {
        Image = image;
    }


    public int getID() {
        return ID;
    }

    public String getFullname() {
        return fullname;
    }

    public String getHomeLocation() {
        return HomeLocation;
    }


    public String getDate() {
        return Date;
    }


    public String getTime() {
        return Time;
    }

    public byte[] getImage() {
        return Image;
    }

    public String getDescription() {
        return Description;
    }

    //---
    public void Save(SQLiteDatabase db)
    {
        try
        {
            ContentValues values=new ContentValues();
            values.put("fullname",fullname);
            values.put("Date",Date);
            values.put("Time",Time);
            values.put("HomeLocation",HomeLocation);
            values.put("Description",Description);
            values.put("Image",Image);
            db.insert("Customer",null,values);
        }
        catch (Exception ex)
        {
            throw  ex;
        }
    }
    public List<Customer>GetCustomers(SQLiteDatabase db)
    {
        try
        {
            List<Customer> events= new ArrayList<Customer>();
            String query="select id,fullname,Date,time,Homelocation,Description,image from Customer";
            Cursor cursor= db.rawQuery(query,null);
            if(cursor.moveToFirst())
            {
                do {
                    Customer customer= new Customer();
                    customer.setID(cursor.getInt(0));
                    customer.setFullname(cursor.getString(1));
                    customer.setDate(cursor.getString(2));
                    customer.setTime(cursor.getString(3));
                    customer.setHomeLocation(cursor.getString(4));
                    customer.setDescription(cursor.getString(5));
                    customer.setImage(cursor.getBlob(6));
                    events.add(customer);


                }while (cursor.moveToNext());
            }
            return events;
        }
        catch (Exception ex)
        {
            throw  ex;
        }

    }
    public void Delete(SQLiteDatabase db)
    {
        try
        {
            db.delete("CustomerDetails","id="+ID,null);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public void Update(SQLiteDatabase db)
    {
        try
        {
            ContentValues values = new ContentValues();
            values.put("Name", fullname);
            values.put("Date", Date);
            values.put("Time", Time);
            values.put("Location", HomeLocation);
            values.put("Description", Description);
            values.put("Image", Image);
            db.update("Customer",values,"id="+ID,null);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

}
