package com.example.cleaningapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CustomerAdapter extends RecyclerView.Adapter<CustomerAdapter.ViewHolder>
{
    SQLiteDatabase db;
    List<Customer> customerList;
    public CustomerAdapter(List<Customer> customers,SQLiteDatabase _db)
    {
        db = _db;
        customerList =customers;

    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater= LayoutInflater.from(parent.getContext());
        View customerItems = inflater.inflate(R.layout.customer_items,parent,false);
        ViewHolder holder= new ViewHolder(customerItems);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Customer customer = customerList.get(position);
        holder.txvCfName.setText(customer.getFullname());
        holder.txvDate.setText("Date: "+customer.getDate()+" Time: "+customer.getTime());
        holder.txvDes.setText(customer.getDescription());
        Bitmap bitmap= BitmapFactory.decodeByteArray(customer.getImage(),0,customer.getImage().length);
        holder.imvEvent.setImageBitmap(bitmap);
        holder.imbDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder= new AlertDialog.Builder(holder.imbDelete.getContext());
                builder.setMessage("Are you sure you want to delete?").setTitle("Confirm Delete").
                        setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                customer.Delete(db);
                                customerList.remove(position);
                                notifyItemRemoved(position);

                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //Nothing to do
                            }
                        });
                AlertDialog dialog= builder.create();
                builder.show();
            }
        });
        holder.imbEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.putExtra("id",customer.getID());
                intent.putExtra("fullname",customer.getFullname());
                intent.putExtra("Date",customer.getDate());
                intent.putExtra("Time",customer.getTime());
                intent.putExtra("Description",customer.getDescription());
                intent.putExtra("Homelocation",customer.getHomeLocation());
                intent.putExtra("Image",customer.getImage());
                ((Activity)view.getContext()).setResult(Activity.RESULT_OK,intent);
                ((Activity)view.getContext()).finish();
            }
        });


    }

    @Override
    public int getItemCount() {
        return customerList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txvCfName,txvDate, txvDes;
        ImageView imvEvent;
        ImageButton imbEdit,imbDelete;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txvCfName = itemView.findViewById(R.id.txvCfName);
            txvDate = itemView.findViewById(R.id.txvDate);
            txvDes = itemView.findViewById(R.id.txvDes);
            imvEvent = itemView.findViewById(R.id.imvEvent);
            imbEdit = itemView.findViewById(R.id.imbEdit);
            imbDelete = itemView.findViewById(R.id.imbDelete);

        }
    }
}