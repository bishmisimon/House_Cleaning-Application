package com.example.cleaningapp;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class FinalPage extends AppCompatActivity {
    TextView text;
    Button btnCustomer;



    @Override
    public void onBackPressed() {
        FinalPage.this.finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_page);
        text = findViewById(R.id.changeText);

        Intent intent = getIntent();
        String s2 = intent.getStringExtra("email");
        text.setText(s2);

        btnCustomer=findViewById(R.id.btnCustomer);
        btnCustomer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(FinalPage.this,CustomerProfile.class);
                startActivity(i);
            }
        });
    }
}




