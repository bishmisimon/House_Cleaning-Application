package com.example.cleaningapp;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import com.google.android.gms.maps.model.LatLng;

public class CustomerProfile extends AppCompatActivity {
    TextView txvID;
    EditText txvCfName, etxtDate, etxtTime, etxtHomeLocation, etxtDes;
    ImageView imvHome;
    Button btnAdd, btnUpdate, btnView;
    Calendar calendar= Calendar.getInstance();
    Bitmap image;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_profile);
        txvID= findViewById(R.id.txvID);
        txvCfName = findViewById(R.id.txvCfName);
        etxtDate = findViewById(R.id.etxtDate);
        etxtTime = findViewById(R.id.eTxtTime);
        etxtDes = findViewById(R.id.etxtDes);
        etxtHomeLocation = findViewById(R.id.etxtHomeLocation);
        imvHome = findViewById(R.id.imvHome);
        btnAdd = findViewById(R.id.btnAdd);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnView = findViewById(R.id.btnView);
        SetDB();

        DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);
                String date="dd/MM/YYYY";
                SimpleDateFormat format = null;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                    format = new SimpleDateFormat(date, Locale.US);
                }
                etxtDate.setText(format.format(calendar.getTime()));
            }
        };
        etxtDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(CustomerProfile.this,listener,
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)).show();

            }
        });
        etxtTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int minute =calendar.get(Calendar.MINUTE);
                TimePickerDialog dialog = new TimePickerDialog(v.getContext(), new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        etxtTime.setText(hourOfDay+":"+minute);
                    }
                },hour,minute,true);
                dialog.setTitle("Select Shedule time");
                dialog.show();
            }
        });

        ActivityResultLauncher<Intent> launcher=
                registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                        new ActivityResultCallback<ActivityResult>() {
                            @Override
                            public void onActivityResult(ActivityResult result) {
                                if(result.getResultCode() == Activity.RESULT_OK)
                                {
                                    Intent intent= result.getData();
                                    LatLng latLng= intent.getParcelableExtra("location");
                                    if(latLng != null)
                                    {
                                        etxtHomeLocation.setText(String.valueOf(latLng));
                                    }
                                }
                            }
                        });
        etxtHomeLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MapsActivity.class);
                launcher.launch(intent);
            }
        });

        ActivityResultLauncher camlauncher= registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        Intent intent= result.getData();
                        image = (Bitmap) intent.getExtras().get("data");
                        imvHome.setImageBitmap(image);
                    }
                }
        );

        imvHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                camlauncher.launch(intent);
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try
                {
                    Customer customer= new Customer();
                    customer.setFullname(txvCfName.getText().toString());
                    customer.setDate(etxtDate.getText().toString());
                    customer.setTime(etxtTime.getText().toString());
                    customer.setHomeLocation(etxtHomeLocation.getText().toString());
                    customer.setDescription(etxtDes.getText().toString());
                    ByteArrayOutputStream stream= new ByteArrayOutputStream();
                    image.compress(Bitmap.CompressFormat.JPEG,80,stream);
                    byte[] imgArray = stream.toByteArray();
                    customer.setImage(imgArray);
                    customer.Save(db);
                    Toast.makeText(getApplicationContext(),
                            "Event Customer",Toast.LENGTH_LONG).show();


                }
                catch (Exception ex)
                {
                    Toast.makeText(getApplicationContext(),
                            "Fail to add Customer :"+ex.getMessage(),Toast.LENGTH_LONG).show();
                }
            }
        });


        ActivityResultLauncher<Intent> launcher1=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>()
                {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode()==Activity.RESULT_OK)
                        {
                            Intent intent=result.getData();
                            txvCfName.setText(intent.getStringExtra("fullname"));
                            etxtDate.setText(intent.getStringExtra("Date"));
                            etxtTime.setText(intent.getStringExtra("Time"));
                            etxtHomeLocation.setText(intent.getStringExtra("location"));
                            etxtDes.setText(intent.getStringExtra("Description"));
                            byte[] imgArray= (byte[]) intent.getExtras().get("Image");
                            image = BitmapFactory.decodeByteArray(imgArray, 0, imgArray.length);

                            imvHome.setImageBitmap(image);
                            txvID.setText(String.valueOf(intent.getIntExtra("id", -1)));


                        }

                    }
                });
        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ViewCustomer.class);
                launcher1.launch(intent);
            }
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try
                {
                    Customer customer= new Customer();
                    customer.setFullname(txvCfName.getText().toString());
                    customer.setDate(etxtDate.getText().toString());
                    customer.setTime(etxtTime.getText().toString());
                    customer.setHomeLocation(etxtHomeLocation.getText().toString());
                    customer.setDescription(etxtDes.getText().toString());
                    customer.setID(Integer.valueOf(txvID.getText().toString()));
                    ByteArrayOutputStream stream= new ByteArrayOutputStream();
                    image.compress(Bitmap.CompressFormat.JPEG,80,stream);
                    byte[] imgArray = stream.toByteArray();
                    customer.setImage(imgArray);
                    customer.Update(db);

                    Toast.makeText(getApplicationContext(),
                            "Customer updated",Toast.LENGTH_LONG).show();


                }
                catch (Exception ex)
                {
                    Toast.makeText(getApplicationContext(),
                            "Fail to update Event :"+ex.getMessage(),Toast.LENGTH_LONG).show();
                }

            }
        });


    }
    private void SetDB()
    {
        try {
            db = openOrCreateDatabase("CustomerDB",MODE_PRIVATE,null);
            db.execSQL("Create Table if not exists Event(id integer primary key Autoincrement,fullname text," +
                    "Date text,Time text,HomeLocation text,Description text,Image blob)");
        }
        catch (Exception ex)
        {
            Toast.makeText(getApplicationContext(),
                    "Error in DB :"+ex.getMessage(),Toast.LENGTH_LONG).show();
        }
    }
}